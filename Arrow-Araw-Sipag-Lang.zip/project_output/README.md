# Arrow Araw: Sipag Lang

> A logic-based arcade puzzle game developed for the **Application Development & Emerging Technology** course.

---

## Project Description

**Arrow Araw: Sipag Lang** is an Android mobile game built with Flutter and Dart. Players are presented with a grid filled with coloured arrows. Each arrow points in one of four directions (up, down, left, right) and must be cleared from the board by tapping it when its escape lane — the straight path from the arrowhead to the grid boundary — is unobstructed. Clearing all arrows before the 60-second timer runs out, with three lives to spare, wins the level.

The game features ten progressively harder levels (8×8 → 18×18 grids, 10 → 100 arrows), a Supabase-backed authentication system, cloud-synced player statistics, and a real-time global internet connectivity monitor that blocks all app functionality when the device goes offline.

---

## Key Features

| Feature | Description |
|---|---|
| **Arcade Logic Puzzles** | 10 levels with procedurally generated, guaranteed-solvable arrow layouts using a reverse-fill algorithm. |
| **Progressive Difficulty** | Grid size and arrow count scale from Level 1 (8×8, 10 arrows) to Level 10 (18×18, 100 arrows). |
| **Online-Only Access** | A real-time global connectivity listener blocks all screens and shows a persistent SnackBar whenever the device goes offline. |
| **User Authentication** | Full Supabase Auth flow: Sign Up (with OTP email verification), Login, and a 3-step Forgot Password recovery. |
| **Player Records** | Wins, Losses, Matches Played, Days Active, and Win Rate — stored in Supabase and displayed on the Records screen with a glassmorphism card grid. |
| **Level Unlock System** | Progress is stored in both SharedPreferences (local) and Supabase (remote). The higher value wins, so offline progress is never lost. |
| **Background Music & SFX** | Lobby music, in-game music, win/lose jingles, and tap sound effects — all independently toggleable from the Settings screen. |
| **Account Management** | Users can update their username, log out, or permanently delete their account from the Settings screen. |

---

## Tech Stack

| Layer | Technology |
|---|---|
| **Framework** | Flutter 3.x (Dart) |
| **Backend / Database** | Supabase (PostgreSQL) — Authentication, game_stats table, level_progress table |
| **State Management** | Provider (`ChangeNotifier`) — `GameProvider`, `AuthProvider`, `ConnectivityProvider` |
| **Connectivity** | `connectivity_plus` package + `dart:io InternetAddress.lookup()` |
| **Audio** | `audioplayers` package — separate players for music and SFX |
| **Local Storage** | `shared_preferences` — caches auth state and level progress for offline resilience |
| **HTTP** | `http` package — used by `ContactScreen` to POST support messages via EmailJS |
| **Email** | EmailJS REST API — sends contact form messages without a custom backend |
| **UI / Animation** | `flutter_animate` — level-unlock card animations on `LevelSelectScreen` |
| **Design Tool** | Figma — used for UI/UX prototyping and screen design |
| **Target Platform** | Android (portrait-only) |

---

## Project Structure

```
lib/
├── main.dart                        # App entry point; registers all providers; injects ConnectivityWrapper globally
├── levels/
│   ├── level_base.dart              # Core game engine: BentLevelStateMixin, arrow rendering, tap logic, HUD
│   ├── level_manager.dart           # Procedural puzzle generator (reverse-fill algorithm) for all 10 levels
│   ├── game_screen_lvl_1.dart       # Level 1 screen  (8×8,  10 arrows)
│   ├── game_screen_lvl_2.dart       # Level 2 screen  (10×10, 20 arrows)
│   └── ...                          # Levels 3–10 follow the same structure
├── models/
│   ├── arrow_model.dart             # ArrowModel data class (legacy GameScreen)
│   └── game_stats_model.dart        # GameStatsModel: wins, losses, matches, days, win rate
├── providers/
│   ├── auth_provider.dart           # Authentication state: sign-up, login, logout, password reset
│   ├── game_provider.dart           # Game state: level timer, lives, arrow list, stats recording
│   └── connectivity_provider.dart   # Real-time internet status listener (NEW)
├── screens/
│   ├── splash_screen.dart           # Launch screen: connectivity check → auth check → routing
│   ├── login_screen.dart            # Email + password login
│   ├── signup_screen.dart           # Registration with optional OTP email verification
│   ├── forgot_password_screen.dart  # 3-step OTP password recovery
│   ├── home_screen.dart             # Main menu: Play, Records, Settings
│   ├── level_select_screen.dart     # 10-level grid; shows unlocked/locked status
│   ├── game_screen.dart             # Legacy single-level game screen (kept for compatibility)
│   ├── records_screen.dart          # Player stats in a glassmorphism 2-column card grid
│   ├── settings_screen.dart         # Audio toggles, account management, legal links
│   ├── contact_screen.dart          # EmailJS contact form
│   ├── about_screen.dart            # App info, team, technology description
│   ├── terms_screen.dart            # Terms of Service (read-only)
│   └── policy_screen.dart           # Privacy Policy (read-only)
├── services/
│   ├── supabase_service.dart        # All Supabase API calls (auth, game_stats, level_progress)
│   ├── audio_service.dart           # Singleton audio controller: music tracks + SFX
│   └── level_unlock_service.dart    # Dual-storage level progress (SharedPreferences + Supabase)
├── utils/
│   ├── app_colors.dart              # Global colour palette and gradient definitions
│   └── constants.dart               # Asset paths, SharedPreferences keys, game configuration
└── widgets/
    ├── background_wrapper.dart      # Reusable city-background shell with optional back button
    ├── connectivity_wrapper.dart    # Global offline overlay + SnackBar manager (NEW)
    ├── game_over_overlay.dart       # Full-screen game-over overlay with Retry/Back actions
    ├── victory_overlay.dart         # Full-screen victory overlay with Next Level/Back actions
    ├── gradient_button.dart         # Reusable gradient CTA button
    ├── gradient_input_field.dart    # Reusable themed text input with optional password toggle
    └── life_indicator.dart          # Row of heart icons showing remaining lives
```

---

## Installation & Running

### Prerequisites

- Flutter SDK `>=3.0.0 <4.0.0` installed and on `PATH`
- Android device or emulator (API 21+)
- Active internet connection (the app is **online-only**)

### Steps

```bash
# 1. Clone or extract the project
cd ARROW-ARAW-SIPAG-LANG-main

# 2. Install dependencies (including connectivity_plus)
flutter pub get

# 3. Run on a connected Android device or emulator
flutter run

# 4. Build a release APK
flutter build apk --release
```

> **Note:** The app requires an internet connection at all times. If the device is offline when the app launches, it stays on the Splash Screen. If connectivity is lost during gameplay, a persistent red SnackBar appears and the UI is blocked until the connection is restored.

---

## Supabase Configuration

The app connects to a Supabase project. The following tables are required:

| Table | Columns | Purpose |
|---|---|---|
| `game_stats` | `user_id`, `total_wins`, `total_losses`, `total_matches`, `total_days`, `updated_at` | Stores per-user lifetime statistics |
| `level_progress` | `user_id`, `highest_unlocked_level`, `updated_at` | Stores the highest level unlocked by each user |

A server-side RPC function `delete_user()` is also required for the account deletion feature:

```sql
create or replace function delete_user()
returns void language plpgsql security definer as $$
begin
  delete from auth.users where id = auth.uid();
end;
$$;
```

---

## Connectivity System (Technical Overview)

The global internet monitor is implemented across two files:

**`ConnectivityProvider`** (`lib/providers/connectivity_provider.dart`)
- Subscribes to `connectivity_plus` stream for real-time network change events.
- On each event, performs a DNS lookup (`InternetAddress.lookup('google.com')`) to confirm actual internet access — not just Wi-Fi association.
- Calls `notifyListeners()` only when status changes, preventing redundant rebuilds.
- Cancels its stream subscription in `dispose()` — no memory leaks.

**`ConnectivityWrapper`** (`lib/widgets/connectivity_wrapper.dart`)
- Injected at the `MaterialApp.builder` level in `main.dart` — wraps every route automatically with zero per-screen changes.
- When offline: renders a full-screen `AbsorbPointer` overlay (blocks all touch input) and shows a persistent red SnackBar reading *"Please check your internet connection."*
- When back online: dismisses the overlay and shows a green SnackBar reading *"Internet connection restored."*

---

## Constraints

- The app is **online-only**. All features (login, gameplay, records, contact) require an active internet connection.
- All game data is stored in Supabase. Local SharedPreferences serve only as a cache.
- Accounts can be registered via the Sign Up screen. Guest access is not supported.

---

## License

© 2026 Arrow Araw Sipag Lang. All rights reserved.
